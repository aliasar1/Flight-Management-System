//package com.company;
//
//public class FindRoute {
//
//    public City[] getCities(String citySource,String cityDestination){
//        int i =0;
//
//        FlightRoutesLinkedList fl;
//        NodeFlight current = flights.head;
//        City[] cities = new City[flights.getCount()+1];
//        while (current != null) {
//            cities[i] = current.source;
//            current = current.next;
//            i += 1;
//        }
//        cities[i] = current.destination;
//        return cities;
//    }
//}
