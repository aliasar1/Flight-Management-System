package com.company;

import java.io.Serializable;
import java.util.ArrayList;

public class NodeFlight implements Serializable {

    public static int nextFlightId = 1;
    public static final int MAX_CAPACITY = 10;
    public int flightId;
    public City source;
    public City destination;
    public ArrayList<NodePassenger> seats;
    public NodeFlight next = null;

    public NodeFlight(City source, City destination) {
        this.flightId = nextFlightId;
        this.source = source;
        this.destination = destination;
        this.seats = new ArrayList<NodePassenger>();
        this.seats.ensureCapacity(MAX_CAPACITY);
//        this.seats = new NodePassenger[5]; //100 seats of NodePassenger class
        nextFlightId++;
    }

    public int getVacantSeats() {
        int count = 0;
        for (int i = 0; i < MAX_CAPACITY; i++) {
            if (getOrNull(seats, i) == null) {
                count++;
            }
        }
        return count;
    }

    public void display() {
        System.out.print(source.name + " --> " + destination.name + "\n");
    }

    public static NodePassenger getOrNull(ArrayList<NodePassenger> al, int index){
        try {
            return al.get(index);
        }
        catch (Exception ex){
            return null;
        }
    }

    public static NodePassenger set(ArrayList<NodePassenger> al, int index){
        try {
            return al.get(index);
        }
        catch (Exception ex){
            return null;
        }
    }
}
